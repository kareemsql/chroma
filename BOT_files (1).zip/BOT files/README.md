# Pyrium - Discord Hack Week

Hey there! This is my official Multi Feature Discord Hack Week Bot Submission! There are some points I need to make.

This bot is made with Discord.PY, (python), so, you need python. The bot was made with python 3.6.5 so i recommend you test it on that. Read the requirements.txt file for the requirements, and install them in CMD using 
"pip install {the requirement without brackets}", or however you want to install it, and all requirements should be installed at their latest versions. Note that in bot.py at the last line, my bots token was replaced with "TOKEN" so just replace that with your bot token (get one by creating an app and bot user at https://discordapp.com/developers). Please don't delete any files or folders/change folder/file names, whether they are empty or not since some commands require those directories to store files and information for later when you use a certain command, or some files and directories are needed to run the bot, and also please dont edit the cogs/fun.py file, to change the token and stuff its all in the bot.py file.
  
  all requirements are included in the requirements.txt file, and should be installed at their latest version. the only thing you need to do in the bot.py is replace TOKEN at the bottom of the code to your testing token. just install the requirements, replace TOKEN with your token, run the bot.py, and all should work fine!

The prefix is: "py."
The help command is "py.help"


NOTES:
Utils folder doesnt need any editing, all is fine.;
Data folder is empty but shouldnt be deleted as some commands need it to store data when they are executed.;
fun.py in cogs folder is just a cog for some of the fun commands in the bot, no editing needed there.;
Everything was tested before upload, bot should start up and all should work fine when all requirements are installed and token is added.;
Don't delete ANYTHING AT ALL in the "assets" folder. EVERYTHING in that folder is important!;

Basically, you don't need to edit anything in the files except replace TOKEN at the last line of bot.py to an actual token

Discord: Insane#0002
