# Responses for the 8ball / ball command
magic_conch_shell = [
    "It is certain",
    "It is decidedly so",
    "Without a doubt",
    "Yes definitely",
    "You may rely on it",
    "As I see it yes",
    "Most likely",
    "Outlook good",
    "Yes",
    "Signs point to yes",
    "Reply hazy try again",
    "Ask again later",
    "Better not tell you now",
    "Cannot predict now",
    "Concentrate and ask again",
    "Don't count on it",
    "My reply is no",
    "My sources say no",
    "Outlook not so good",
    "Very doubtful"
]

# Results for the "Battle" Command
fight_results = [
    "and it was super effective!",
    "but %user% dodged it!",
    "and %user% got obliterated!",
    "but %attacker% missed!",
    "but they killed each other!",
    "and it wiped out everything within a five mile radius!",
    "but in a turn of events, they made up and became friends. Happy ending!",
    "and it worked!",
    "and %user% never saw it coming.",
    "but %user% grabbed the attack and used it against %attacker%!",
    "but it only scratched %user%!",
    "and %user% was killed by it.",
    "but %attacker% activated %user%'s trap card!",
    "and %user% was killed!"
]

