﻿lenny = "( ͡° ͜ʖ ͡° )"

sombra = "```\n                       :PB@Bk:                         \n                   ,jB@@B@B@B@BBL.                     \n                7G@B@B@BMMMMMB@B@B@Nr                  \n            :kB@B@@@MMOMOMOMOMMMM@B@B@B1,              \n        :5@B@B@B@BBMMOMOMOMOMOMOMM@@@B@B@BBu.          \n     70@@@B@B@B@BXBBOMOMOMOMOMOMMBMPB@B@B@B@B@Nr       \n   G@@@BJ iB@B@@  OBMOMOMOMOMOMOM@2  B@B@B. EB@B@S     \n   @@BM@GJBU.  iSuB@OMOMOMOMOMOMM@OU1:  .kBLM@M@B@     \n   B@MMB@B       7@BBMMOMOMOMOMOBB@:       B@BMM@B     \n   @@@B@B         7@@@MMOMOMOMM@B@:         @@B@B@     \n   @@OLB.          BNB@MMOMOMM@BEB          rBjM@B     \n   @@  @           M  OBOMOMM@q  M          .@  @@     \n   @@OvB           B:u@MMOMOMMBJiB          .BvM@B     \n   @B@B@J         0@B@MMOMOMOMB@B@u         q@@@B@     \n   B@MBB@v       G@@BMMMMMMMMMMMBB@5       F@BMM@B     \n   @BBM@BPNi   LMEB@OMMMM@B@MMOMM@BZM7   rEqB@MBB@     \n   B@@@BM  B@B@B  qBMOMB@B@B@BMOMBL  B@B@B  @B@B@M     \n    J@@@@PB@B@B@B7G@OMBB.   ,@MMM@qLB@B@@@BqB@BBv      \n       iGB@,i0@M@B@MMO@E  :  M@OMM@@@B@Pii@@N:         \n          .   B@M@B@MMM@B@B@B@MMM@@@M@B                \n              @B@B.i@MBB@B@B@@BM@::B@B@                \n              B@@@ .B@B.:@B@ :B@B  @B@O                \n                :0 r@B@  B@@ .@B@: P:                  \n                    vMB :@B@ :BO7                      \n                        ,B@B                           ```"

tableflip = "(╯°□°）╯︵ ┻━┻"

doubleflip = "┻━┻ ﾐヽ(ಠ益ಠ)ノ彡┻━┻"

misc_weeb_face = "(・`ω´・)"